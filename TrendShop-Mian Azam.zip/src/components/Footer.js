

function Footer() {
    return (
        <footer>
            <div className="footerContainer container">
                <ul>
                    <li className="insta">
                        <i class="fa-brands fa-instagram "></i>
                    </li>
                    <li className="fb">
                        <i class="fa-brands fa-facebook "></i>
                    </li>
                </ul>
            </div>
        </footer>
    )
}

export default Footer